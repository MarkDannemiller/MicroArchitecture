Development TODO list

For Human User:
- [ ] Test code and generate GTKWave graphs
- [ ] Organize into powerpoint